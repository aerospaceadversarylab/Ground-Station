
# 3D Printed Designs

The RotatorSTL zip below contains all of the necessary .stl files for 3D Printing the ground station.

The Wiring zip below contains all images and diagrams pertaining to wiring.
